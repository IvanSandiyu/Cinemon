using Cinemon.Web.Models.DTOs;

namespace Cinemon.Web.Services
{
    public sealed class UsuarioApiService
    {
        private readonly HttpClient _httpClient;

        public UsuarioApiService(IHttpClientFactory httpClientFactory)
        {
            _httpClient = httpClientFactory.CreateClient("CinemonApi");
        }

        public async Task<UsuarioDto?> ObtenerPorIdAsync(
            int id,
            CancellationToken cancellationToken = default)
        {
            return await _httpClient.GetFromJsonAsync<UsuarioDto>(
                $"api/usuarios/{id}",
                cancellationToken);
        }
    }
}