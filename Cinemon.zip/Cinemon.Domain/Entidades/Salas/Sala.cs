﻿using Cinemon.Domain.Entidades.Butacas;
using Cinemon.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cinemon.Domain.Entidades.Salas
{
    public class Sala
    {
        public int Id {  get; set; }
        public int Numero { get; set; }
        public TipoSala TipoSala { get; set; }

        public ICollection<Butaca> Butacas { get; private set; } = [];

        public Sala(int numero, TipoSala tipoSala)
        {
            Numero = numero;
            TipoSala = tipoSala;
        }
    }

    

}
